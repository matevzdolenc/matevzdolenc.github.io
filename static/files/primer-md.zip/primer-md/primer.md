# Novi trendi na področju sodelavskega inženirstva

Asist. dr. Robert Klinc, doc. dr. Matevž Dolenc, prof. dr. Žiga Turk

## POVZETEK

Računalniki se v industriji, ki se ukvarja z grajenim okoljem (kar običajno poimenujemo z besedo gradbeništvo), pojavljajo vse od petdesetih let prejšnjega stoletja. Pri tem je informatika v gradbeništvu prešla iz reševanja tehnoloških problemov v delo in sodelovanje s pomočjo orodij informacijskih in komunikacijskih tehnologij (IKT). V članku predstavljamo razvoj gradbene informatike skozi čas, trende v informacijskih in komunikacijskih tehnologijah, ki vplivajo na gradbeno industrijo ter ključne raziskovalne in razvojne teme, s katerimi se bo gradbena informatika morala spopasti v naslednjem obdobju.

## SUMMARY

Computers in architecture, engineering and construction (AEC) industry emerged during the 1950s. From there on, construction informatics evolved from solving technological problems to the work and collaboration using information and communication technologies (ICT). This paper presents the development of the construction informatics over time, ICT trends affecting AEC industry and the key research and development (R&amp;D) issues that construction informatics will have to face in the near future.

## 1. Uvod

Od prazgodovine naprej je graditev terjala sodelovanje. Pogoj za sodelovanje pa je komuniciranje med sodelujočimi. Glede na prevladujoč način komuniciranja, lahko zgodovino gradbeništva zadelimo v tri obdobja (slika 1; Turk, 2001b). V prvem so komunicirali pretežno ustno. Dokumentacija ni obstajala, zato je morala biti oseba, ki je načrtovala in planirala gradnjo pretežno fizično prisotna na kraju gradnje. Po iznajdbi poceni papirja konec 15. stoletja se začne sistematično razvijati tehnično dokumentiranje. Gradbeni procesi zelo nazorno razpadejo na informacijske in materialne. V privih se pripravljajo načrt in plani, v drugih se fizično gradi. Stoletja je bila papirna tehnična dokumentacija osnovno komunikacijsko orodje med inženirji, arhitekti in gradbinci na gradbišču. Od konca 1980ih se papir umika digitalnemu komuniciranju, računalniška tehnologija pa se v vlogi orodja (npr. programi za račun konstrukcij), pomočnika (npr. programi, ki generirajo možne tlorise stavbe) ali medija (programi, ki omogočajo prikaz načrtov in komunikacijo med udeleženci) pojavlja v vseh informacijskih in materialnih podprocesih.

 ![](primer-slika-1.png)

Slika 1: Komunikacijske revolucije in spremembe vzorcev delovanja v gradbeništvu (Turk, 2001b)

Sprva je informacijska tehnologija s tehnično drugačnimi rešitvami obnavljala stare vzorce dela. Pošiljanje telefaksov je npr. zamenjala elektronska pošta. Risanje načrtov, kjer je tehnik vlekel s tušem po papirju, so nadomestili programi, kjer so črte vlekli po računalniku. Računanje konstrukcij peš je so nadomestili računalniški programi za analizo konstrukcij. Sodelavci inštituta IKPIR so tudi na tem podpodročju orali ledino od sedemdesetih let naprej.

### 1.1 Tehnološki pritisk

Razvoj informacijske in komunikacijske tehnologije pa je zelo hiter. Vezan je na Moorov zakon, ki vsako leto in pol podvoji hitrost mikroprocesorjev, enako hitro pa naraščajo tudi hitrosti omrežnih povezav in padajo cene pomnilniškega prostora. Nove informacijske tehnologije spreminjajo paradigmo, spreminjajo vzorec dela, kar ima za posledico najprej spremembo navad, sledi sprememba organiziranosti in organizacij, nazadnje pa pride tudi sprememba regulative.

Današnji trenutek zaznamujejo trije veliki trendi na področju gradbene informatike (Slika 2):

 ![](primer-slika-2.png)

Slika 2: Trendi tehnološkega razvoja, posledica na procese v gradbeništvu in vpliv na računalniško integrirano graditev.

Prvič, napredek pri razvoju procesne tehnologije ter metod za numerično modeliranje omogoča vse hitrejše in obsežnejšo analizo kot tudi sintezo informacij. Posledica tega trenda je avtomatizacija odločanja ko gre za analizo rešitev kot tudi generiranje alternativnih rešitev, predvsem v arhitekturi in prostorskem planiranju, z uporabo metod umetne inteligence.

Drugič, črta se kot osnovni gradnik risbe in dokumentacije počasi a nezadržno umika podatkovni strukturi, objektu, ki na bistveno bolj natančen, konsistenten, predvsem pa na strukturiran način opisuje zamišljeno zgradbo. Množico takih objektov imenujemo informacijski model zgradbe ali virtualna zgradba. Desetletja dolg razvoj konceptualnega modeliranja v gradbeništvu ter modeliranja gradbenih produktov je našel komericialno udejenjenje v evoluciji CAD programov v BIM programe. Ključni prispevek BIM programov k celovitosti gradnje je, da omogočajo informacijsko celovitost - torej izmenjavo podatkov med programi na visokem pomenskem nivoju. Kako so lahko uporabni za načrtovanje energetsko učinkovitih zgradb pišeta Todorović in Turk v sosednjem članku.

Tretjič, računalnik postaja komunikacijsko orodje in platforma za sodelovanje ljudi in podjetij. Ta smer razvoja je še posebej hitra od pojava spleta 2.0 in razcveta tehnologij, ki povezujejo ljudi. Laikom so poznani kot Facebook, LinkedIn, Google Docs, Skype, funkcionalno podobne rešitve pa obstajajo tudi posebej za inženirje. A vendar so se inženirji sredi prvega desetletja tega stoletja znašli v položaju, ko so bila ta splošna orodja za sodelovanje uporabnejša od specializiranih rešitev za gradbenike.

### 1.2 Vpliv na celovitost gradnje

Predvsem zadnja dva trenda bistveno prispevata k povezanosti in celovitosti gradnje, torej k nečemu, kar je začelo razpadati pred stoletji tisti trenutek, kot cela zgradba z vsemi podrobnostmi, ni več šla v glavo enega samega stavbenika, ampak so se znanja specializirala, strokovnjaki pa se med seboj pogovarjali v natančnem jeziku matematičnih izračunov in tehničnih risb.

Informacijski modeli gradbene procese vse tesneje povezujejo na nivoju podatkov, dobro, pogosto brez človekove intervencije, lahko povežejo programe med seboj. Povežejo tisti del gradbeništva, ki je predvidljiv in zato lahko formalen - spravljen v formo, s katero znajo delati programi BIM. Računalnik kot komunikacijska platforma pa poveže ljudi, ki so sposobni pogledati preko modelov in ki rešujejo probleme, ki ostajajo onkraj dosega informacijske tehnologije. Povezujejo ljudi, ki so sposobni obvladati enkratno naravo gradbenih produktov in projektov ter še vedno visoko stopnjo improvizacije, ki je posledica te enkratnosti.

Tretji nivo povezovanja se dogaja na čisto tehničnem nivoju, in ki je skupen vsem trem naštetim trendom. Gre za &quot;računalništvo kot komunalo&quot; (computing as utility) ter mobilno računalništvo. Prvo na čisto nov način daje računalniške vire (procesiranje, hranjenje podatkov, komunikacije) na razpolago uporabnikom. Postajajo del gospodarske infrastrukture; podobno, kot se podjetja praviloma ne ukvarjajo s tem, da imajo svoj izvir vode, svojo kanalizacijo in elektrarno, tako se iz organizacij selijo tudi računalniške storitve.

### 1.3 Trendi

Računalništvo je šlo skoz več nihanj med lokalnim in oddaljenim. Na IKPIR se spominjamo časov, ko smo na FGG samo luknjali kartice, računalo pa se je nekje daleč. Sledili so osebni računalniki, ki so delo opravili na uporabnikovi mizi. Potem so se pojavili strežniki, ki so del hrambe podatkov in komunikacije izvedli v računskem centru. Danes smo priča selitvi računskih virov v &quot;oblak&quot; in virtualizaciji računalnikov in omrežij. Osebni računalnik je samo okno, skozi katerega izkoriščamo vire v oblaku.

V ta vzorec se zelo dobro vklaplja mobilno računalništvo. Mobilna naprava ima zaradi porabe energije in zahteve po majhni teži ne more zagotavljati velike procesne moči in hrambe podatkov, lahko pa je prav uporabno in v vsakem trenutku in povsod dostopno okno v virtualizirane storitve v oblaku.

Virtualizacijska tehnologija je hkrati odločna podpra vzorcu virtualnega podjetja - torej skupine partnerjev, ki pride skupaj za en projekt - ki je že stoletja prisoten v gradbeništvu. Zdaj je lahko tudi tehnološko podprt.

V članku predstavljamo, kako te trende pri nas razumemo in naše prispevke pri razvoju tehnologij.

## 2. Smeri razvoja informatike in gradbene informatike

Informacijske tehnologije so skupaj s povezanimi področji (telekomunikacije in elektronika) popolnoma spremenile načine upravljanja informacij in komunikacije med ljudmi v industriji. To se je zgodilo predvsem na tri načine (Dainty et al., 2006):

- s pospešitvijo procesiranja informacij;
- z olajšanjem dostopa do informacij;
- z izboljšanjem informacijskih sistemov za upravljanje za bolj učinkovito odločanje in nadzor.

Gradbena industrija je računalnik in informacijske tehnologije sprejela v treh korakih (Turk in Cerovšek, 2001):

1. Najprej so računalnik uporabljali predvsem kot pomoč inženirjem pri reševanju vedno večjih modelov. Neposreden rezultat je bil prihranek pri času, prav tako je bila inženirjem naenkrat dana možnost doseganja večje natančnosti in razvoja bolj zapletenih modelov.
2. V naslednjem koraku so računalniki nadomestili risalne mize.
3. Tretje obdobje se je pričelo sredi osemdesetih let s pojavom prvih osebnih računalnikov. Od takrat naprej je računalnik nepogrešljivo orodje in se uporablja pri vsakdanjem inženirskem delu.

Za četrto obdobje IKT in računalnika v gradbeništvu štejemo internet. Pred široko javno uporabo interneta so bila poslovna računalniška okolja običajno omejena na vpeljavo znotraj ene same organizacije. Hiter razvoj internetnih informacijskih tehnologij je organizacijam dal možnost uporabe in vpeljave tehnoloških rešitev, ki so presegale prej veljavne omejitve, ter jim hkrati ponudil možnost ustvarjanja novih, bolj učinkovitih poslovnih procesov in izboljšanje medorganizacijskih delovnih praks (Becerik, 2004).

Gradbeništvo se je razmahu svetovnega spleta pridružilo sredi devetdesetih let, ko se je internet prvič pojavil v znanstvenih in strokovnih prispevkih na gradbeniških kongresih in delavnicah (Turk, 2001b). Kmalu se je pokazalo, da gre za uporabno in udobno tehnologijo, ki procese v primerjavi s tradicionalnim načinom pohitri, poenostavi in poceni, hkrati pa naloge opravi bolj zanesljivo. Gradbena industrija je razmeroma hitro odkrila komunikacijske možnosti novih tehnologij, ki so se kmalu uveljavile vzdolž celotnega sektorja, kljub temu pa ni izkoristila celotnega potenciala novo razvitih IKT.

Kljub temu, da IKT nudijo izjemno veliko možnosti na področju komunikacije, sodelovanja ter upravljanja in da gre za informacijsko precej zahtevno industrijo, gradbeništvo še vedno zaostaja pri uvajanju novih produktov, procesov in tehnologij (Becerik, 2004). Razlogov za to je več. Tako Turk (1999) kot Cerovšek (2002) ugotavljata, da ima pri odnosu gradbeništva do IT ključno vlogo fenomen enkratnosti, saj gre za:

- **enkraten produkt:** gradbeni izdelki (stavbe in inženirski objekti) so praviloma edinstveni;
- **enkraten proces:** procesi načrtovanja, gradnje, in vzdrževanja so skoraj vedno edinstveni;
- **enkraten krog sodelujočih:** proces načrtovanja, gradnje ali vzdrževanja opravlja vedno druga skupina izvajalcev in podizvajalcev, ki so si lahko že pri naslednjem projektu konkurenti, zato je vsem v interesu deliti samo toliko, kolikor je nujno potrebno;
- **enkraten obseg** navedenih treh kategorij, tako po kvaliteti kot kvantiteti.

Zaradi vsega naštetega se gradbeništvo od drugih industrij loči tudi na področju informacijskih rešitev (Turk, 1999):

- omogočati mora izdelke, ki jih ni mogoče opisati s standardiziranimi modeli;
- omogočati mora preglednost modelov za izmenjavo med aplikacijami;
- osredotočiti se mora na komunikacijo človek-človek ter podpirati improvizacijo kot pomemben način opravljanja nalog v gradbeništvu;
- graditi mora tanek sloj nad zmerno tehnično in človeško infrastrukturo.

V zadnjih 15 letih se je zvrstila množica evropskih (in tudi nacionalnih) projektov, ki so se ukvarjali s področjem z IKT podprtega sodelovanja v inženirstvu (slika 3).

 ![](primer-slika-3.png)

Slika 3: Časovni potek projektov IKT podprtega sodelovanja v inženirstvu

Becerik (2004) je v svoji raziskavi spletnih sistemov za upravljanje projektov v gradbeništvu uvedel obdobja, v katera lahko časovno razvrstimo tudi informacijsko-komunikacijske projekte za sodelovanje v inženirstvu na splošno:

- 1995–1997: pionirji. V tem obdobju so se pojavili prvi raziskovalni projekti, ki so se posebej usmerili v raziskovanje potenciala informacijsko-komunikacijskih tehnologij za inženirstvo. Med pionirji je bila tudi Fakulteta za gradbeništvo in geodezijo (FGG) Univerze v Ljubljani (UL), saj je Katedra za gradbeno informatiko (KGI) kot partner sodelovala pri projektu ToCEE;
- 1997–2000: novi na sceni. Drugi val projektov je že prinesel prve programe pristopov k temi, število projektov se je postopoma povečevalo;
- 2000–2001: eksplozija. Na prelomu tisočletja je začela svoje delo množica projektov. Eksplozija delno sovpada s programom financiranja EU, delno pa lahko navdušenje pripišemo obdobju podjetij .com, ki so cvetela do poka internetnega balona. KGI je v tem obdobju sodelovala v projektu ISTforCE;
- 2001–2004: spreminjanje in razvijanje. Po poku internetnega balona se je začetno navdušenje nekoliko umirilo, število projektov se je stabiliziralo, prednostne naloge v raziskavah so se izostrile in konsolidirale;
- 2004–2007: komunikacija. V tem obdobju se je raziskovalo predvsem v smeri komunikacijske infrastrukture v podporo inženirskim procesom in dejavnostim. KGI je v tem obdobju koordinirala projekt InteliGrid;
- 2007–: sodelovanje. Od pojava in uveljavitve spleta 2.0 dalje se raziskuje predvsem v smeri učinkovitega sodelovanja.

### 2.1 Novodobni socialni, tehnološki in poslovni trendi

Svetovni splet je v zadnjem desetletju ali dveh korenito spremenil gospodarstvo in tako ali drugače vplival na večino svetovnega prebivalstva. Splet danes ne predstavlja zgolj vira informacij, predstavlja tudi način poslovanja.

Svet je danes povezan bolj kot kadarkoli prej, saj so tehnološke povezave pokrite s socialnimi omrežji. Fenomen, ki mu pravimo splet 2.0, predstavlja konvergenco internetnega sveta s pomočjo množice različnih novih orodij za komunikacijo, interakcijo in sodelovanje (Fuller et al., 2009). Spivack (2007a) je krivuljo naraščanja tehnoloških in socialnih povezav opisal kot na videz stalno rastočo (glej sliko 4), napoved razvoja tehnologij in računalniških okolij pa je razdelil na  intervale oziroma »obdobja«. Trenutno se v razvoju interakcijskih in komunikacijskih orodij nahajamo na meji obdobij spleta 2.0 in spleta 3.0 (imenovanega tudi semantični splet).

 ![](primer-slika-4.png)

Slika 4: Semantika informacijskih in socialnih povezav (Spivack, 2007a)

#### 2.1.1 Splet 2.0

Splet 2.0 je nova generacija spletnih storitev in predstavlja evolucijo (ter obenem tudi revolucijo) spleta s tehnološkega in sociološkega vidika. O&#39;Reilly (2005) je prepričan, da splet 2.0 nima točno določene meje, temveč zgolj gravitacijsko jedro. Velja ocena, da gre za trend oziroma smer, v katero se splet razvija, in ne za objekt, ki ga lahko ustvarimo (Jewell 2007). Nivi (2005) je zapisal, da gre za odnos, ki teži k radikalno odprti komunikaciji in tudi skupnosti.

O&#39;Reilly (2006) je zapisal naslednjo (kompaktno) definicijo spleta 2.0:

Splet 2.0 je poslovna revolucija v računalniški industriji, ki sta jo povzročila prehod k Internetu kot platformi in poskus razumeti pravila, ki omogočajo uspeh na tej platformi. Glavno pravilo za uspeh je naslednje: zgraditi je treba aplikacijo, ki upošteva mrežni učinek in ki z naraščanjem števila uporabnikov postaja boljša in boljša.

Miller (2005) razpravlja, da so posledice fenomena spleta 2.0 med drugim:

- .pojav spletnih storitev, ki uporabnikom zagotavljajo dodano vrednost v pravem času in na pravem mestu v pravi obliki, podatke pa pridobivajo iz širokega spektra zalednih sistemov;
- .ustanavljanje ad-hoc povezav med storitvami in za njih tam, kjer so potrebne, brez dragih in časovno potratnih pogodb in sporazumov;
- .razdruževanje vsebin in storitev na uporabniku bolj razumljive komponente, manjšanje števila posrednikov in posledično bolj neposreden dostop do spletnih virov;
- .pretvorba pasivnih prejemnikov v aktivne sooblikovalce vsebin, ki so nato preoblikovane, združene ali kombinirane na voljo na mnogo različnih načinov;
- .zamenjava dragih monolitnih sistemov z računalniškimi okolji, ki podpirajo namenske komponente, kar zagotavlja želeno medobratovalnost.

#### 2.1.2 Tehnologije spleta 2.0

Splet 2.0 pokriva široko paleto tehnologij, ki se ne razlikujejo bistveno od tehnologij tradicionalnega spleta, saj je drugačna le uporaba. Kljub temu med temeljne tehnologije spleta 2.0 uvrščamo predvsem:

- **CSS** (Cascading Style Sheets): CSS je jezik za opis predstavitvene semantike (videza in oblike) dokumenta, zapisanega v označevalnem jeziku. S CSS se vsebina dokumenta loči od oblike, kar uporabnikom in razvijalcem omogoča več prožnosti in nadzora;
- **Ajax** (Asynchronous JavaScript and XML): Ajax je skupina povezanih razvojnih tehnik spletnega programiranja, ki omogočajo ustvarjanje interaktivnih aplikacij na uporabniški strani. Z Ajaxom lahko spletne aplikacije pridobivajo podatke s strežnika nesočasno (asinhrono) ter v ozadju brez motenj prikaza in obnašanja spletne strani (Garret, 2005);
- **Adobe Flash™**: kljub temu, da je bila tehnologija Adobe Flash™ na voljo že pred pojavom spleta 2.0, je šele tedaj dobila pravi zagon, zlasti ker omogoča vsebine, ki jih tradicionalno uporabljani HTML ne zmore. To velja predvsem za prikaz in predvajanje videa in zvoka. Največja slabost te tehnologije je strojna zahtevnost, zato jo v zadnjem času predvsem zaradi naraščanja števila pametnih mobilnih naprav precej uspešno izriva standard HTML5, ki pa še ni dovolj dobro podprt v brskalnikih;
- **RSS** (Really Simple Syndication, tudi Rich Site Summary ali RDF Site Summary):RSS je družina formatov spletnih virov (RSS, RSS2, Atom itd.), temelječih na standardu XML. Omogoča objavljanje redno osveženih informacij, ki jih je mogoče pregledovati s pomočjo različnih programskih aplikacij;
- **OpenID in OAuth:** Z naraščanjem števila spletnih storitev spleta 2.0 so se pojavile težave z avtentikacijo uporabnikov in varnostjo njihovih podatkov. Uveljavila sta se predvsem dva odprta standarda: OpenID in OAuth. V zadnjem času pobuda prevzema standard OAuth, saj so ga podprle vse priljubljene spletne storitve, kljub temu pa je prednost standarda OpenID v tem, da ne temelji na centralnem preveritvenem organu.

Značilnost tehnologij in storitev spleta 2.0 je, da ne gre nikoli za zaključeno (ali celo zaprto) celoto, saj vsaka uspešna storitev nudi programski vmesnik (API), ki omogoča uporabo storitve na programskem nivoju in posredno tudi izboljšanje storitve. To pomeni, da storitve ni treba uporabljati na predvideni način in celo v predvideni namen, ampak se lahko vsaka storitev prek programskih vmesnikov prilagodi (spremeni) in ponudi v drugačni (izboljšani in obogateni) podobi. Tako lahko praktično vsako storitev z nekaj znanja spremenimo po lastnih željah (prenesemo na drugo platformo, dodamo funkcionalnost ipd.).

#### 2.1.3 Storitve za spletno druženje in spoznavanje (socialna omrežja)

Storitve za spletno druženje in spoznavanje (SNS) so evolucija spletnih skupnosti in gostujočih storitev in so razmeroma nov koncept, katerega število uporabnikov v zadnjih letih raste eksponentno. Komisija Evropskih skupnosti (2009b:4) je storitve za spletno druženje in spoznavanje opredelila kot »spletna komunikacijska računalniška okolja, ki uporabnikom omogočajo ustvarjanje omrežij ali vključevanje v omrežja enako mislečih uporabnikov«.

Shuen (2008) razpravlja, da je spletno mreženje precej podobno mreženju v vsakdanjem življenju brez povezave v internet, saj so pri obeh pomembne socialne spretnosti. Razlika je ta, da povezovanje prek spletnih strani, elektronske pošte ali storitev za takojšnje sporočanje daje vtis navidezne bližine, pri čemer ni potrebe po vljudnostnem kramljanju. Shuen (2008) ugotavlja, da kljub temu ni zamenjava za osebni stik, vsekakor pa spreminja družbene vzorce, ki smo jih vajeni.

Preprosta in hitra digitalna povezljivost je premaknila težišče socialnega mreženja od ustvarjanja, preslikav in širjenja k iskanju novih načinov za izkoriščanje lastnega omrežja (Shuen, 2008).

### 2.2 Tehnološka evolucija

Komisija Evropskih skupnosti (2009a) je s sodelovanjem strokovnjakov iz industrije opredelila štiri ključne dejavnike, ki bodo vplivali na industrijo programske opreme v naslednjih letih: storitveno usmerjeno arhitekturo (SOA), računalništvo v oblaku, poslovno okolje 2.0 in semantični splet.

#### 2.2.1 Storitveno usmerjena arhitektura (SOA)

Storitveno usmerjena arhitektura (SOA) je pristop k razvoju programske opreme, pri katerem se za povezavo ponovno uporabnih aplikacij v medobratovalne storitve uporabi fleksibilna in standardizirana arhitektura (Komisija Evropskih skupnosti, 2009a). Uporabi se lahko kot arhitektura za novo načrtovane rešitve ali kot načrt za rekonstrukcijo in poenostavitev obstoječih kompleksnih informacijskih rešitev (Medeot, 2007).

Za razliko od modelov odjemalec/strežnik, ki jih zaznamuje integracija po principu čvrste povezanosti ter posledično drago vzdrževanje in nadgradnja, so pri SOA posamezni deli porazdeljenega informacijskega sistema šibko povezani, kar razvijalcem omogoča, da o storitvi vedo le to, kje jo najdejo in kako z njo komunicirajo (Komisija Evropskih skupnosti, 2009a; Medeot, 2007).

Kot pristop k razvoju programskih rešitev, ki organizacijam omogoča večjo prožnost in hitrost prilagajanja, enostavnejšo povezavo razpoložljivih sistemov in novih tehnologij ter preprostejše vzdrževanje in nadgradnjo, se je SOA uveljavila tudi v poslovnem svetu (Kempiners in Beck, 2007). Storitve je mogoče vključiti v popolnoma heterogena poslovna okolja, pri čemer se gradijo, uporabijo in ponovno uporabijo glede na spreminjajoče se poslovne potrebe (Komisija Evropskih skupnosti, 2009a).

#### 2.2.2 Računalništvo v oblaku

Računalništvo v oblaku je model uporabe informacijskih rešitev v obliki storitev, dostopnih na internetu, za razliko od tradicionalnega načina, pri katerem so rešitve nameščene na strežnikih ali osebnih računalnikih v podjetju. Ime je izpeljano iz znaka, ki se je v omrežnih diagramih uporabljal in se še uporablja za internet (Easynet, 2008). Računalništvo v oblaku je postal splošni izraz za prilagodljive informacijske storitve in služi kot krovni pojem za zagotavljanje storitev ko so hramba podatkov, računska moč, programska razvojna okolja in oprema, ki so končnim uporabnikom dostopni prek interneta (Komisija Evropskih skupnosti, 2009a).

Računalništvo v oblaku je:

- model primernega in na zahtevo mrežnega dostopa do zaloge računalniških virov (npr. omrežij, strežnikov, shrambe, uporabniških programov in storitev), ki se lahko zagotovijo, uporabijo in sprostijo z minimalnimi napori upravljavca ter ponudnika storitve« (Mell in Grance, 2009);
- priprava in oskrba z računalniškimi storitvami – računsko močjo, podatkovno shrambo, pasovno širino in namensko programsko opremo – prek omrežja, kadar je to potrebno« (Hartman in Beck, 2009:2);
- oblika računalništva, kjer so računalniške zmogljivosti dostopne _kot storitve_, kar uporabnikom omogoča dostop do tehnoloških storitev _v oblaku_ brez potrebe po znanju, nadzoru ali zavedanju o tehnologiji, ki jih podpira« (Wikipedia, cit. po CCUCDG, 2009a:5).

Uveljavili so se predvsem trije modeli računalništva v oblaku (Mell in Grance, 2009; CCUCDG, 2009a; CCUCDG, 2009b; glej sliko 5):

- programska oprema kot storitev ( **SaaS** ): uporabnik uporablja aplikacije, vendar ne nadzoruje operacijskega sistema, strojne opreme ali omrežne infrastrukture, na kateri teče. Aplikacije so dostopne prek različnih naprav s pomočjo vmesnikov lahkih odjemalcev (npr. spletna pošta) - primeri: salesforce.com, Google GMail, Netsuite, ...
- računalniško okolje kot storitev ( **PaaS** ): omogoča postavitev lastnih aplikacij v računalniško okolje v oblaku, če so aplikacije skladne z zahtevami ponudnika (pravi programski jezik, prava orodja). Uporabnik nima nadzora nad osnovno infrastrukturo (operacijski sistem, strojna oprema, omrežna infrastruktura), lahko pa ima dostop do nekaterih namestitvenih možnosti - primeri: Google App Engine, Microsoft Azure, Cloud Foundry, ...
- infrastruktura kot storitev ( **IaaS** ): omogoča nadzor nad vsemi glavnimi računalniškimi viri, kot so računska moč, shranjevanje podatkov, omrežne komponente (tudi požarni zid in sistemi za izenačevanje obremenitve) in vmesna programska oprema. Uporabnik ima nadzor nad operacijskim sistemom, vendar nima nadzora nad osnovno infrastrukturo - primer: Amazon EC2, GoGrid, VMware, ...

 ![](primer-slika-5.png)

Slika 5: Modeli računalništva v oblaku

Od tradicionalnega modela upravljanja in vzdrževanja programske opreme se loči po tem, kje so aplikacije nameščene in kdo jih vzdržuje (Hartman in Beck, 2009):

- programska oprema, ki teče na lokaciji podjetja, za svoje nemoteno delovanje zahteva nakup in vzdrževanje strojne opreme. Na ta način ima podjetje ves nadzor nad aplikacijami in podatki, vendar ima obenem višje stroške in težje umerja potrebe;
- če programska oprema teče pri ponudniku gostovanja, se stroški vzdrževanja infrastrukture in upravljanja delijo;
- programska oprema, ki teče kot storitev v oblaku, nudi manj možnosti neposrednega nadzora, a večjo ekonomičnost in preprostejše umerjanje potreb.

Osnovni modeli postavitve računalništva v oblaku so štirje (Mell in Grance, 2009; CCUCDG, 2009a; CCUCDG, 2009b):

- **zasebni oblak:** oblak je postavljen zgolj za eno organizacijo. Upravlja in vzdržuje ga lastnik ali zunanji izvajalec, lahko je postavljen znotraj ali zunaj organizacije;
- **oblak skupnosti:** oblak si deli več organizacij, ki tvorijo skupnost. Upravljajo in vzdržujejo ga lastniki ali zunanji izvajalci, lahko je postavljen znotraj ali zunaj organizacij;
- **javni oblak:** infrastruktura je v lasti ponudnika storitev v oblaku in je javno dostopna;
- **hibridni oblak:** hibridni oblak je kombinacija javnega in zasebnega oblaka. Uporabniki po tem modelu manj pomembne poslovne procese in informacije obdelujejo v javnih oblakih, medtem ko občutljive storitve in podatke zadržijo v zasebnem oblaku. Povezava med obema poteka prek standardnih in zaščitenih tehnologij, ki omogočajo prenosljivost.

#### 2.2.3 Poslovno okolje 2.0

Naraščanje priljubljenosti digitalnih računalniških okolij za ustvarjanje, deljenje in filtriranje informacij na internetu (poimenovanih tudi storitve spleta 2.0) kot posledico nezadovoljstva nad zastarelimi tehnologijami v poslovnem okolju je McAfee (2006a) združil pod krovnim pojmom poslovno okolje 2.0. Poslovno okolje 2.0 združuje tehnologije in računalniška okolja spleta 2.0, ki jih lahko strokovni delavci, katerih primarna naloga je ustvarjanje ter uporaba znanja in informacij, pri svojem delu uporabljajo. Zaposleni, vešči digitalnih opravil, tudi v svojem poslovnem okolju pričakujejo enake (preproste, učinkovite, splet 2.0) metode in orodja za komuniciranje, saj so ta prav s pojavom socialnih omrežij prvič omogočila uporabno ter preprosto tehnološko podprto komunikacijo in sodelovanje, dostopno širšim množicam.

McAfee (2006b) je poslovno okolje 2.0 opredelil kot »uporabo proste socialne programske opreme v podjetjih«, kjer prosta programska oprema ni vnaprej določena in nima vnaprej pripravljenega pretoka dela, je neodvisna od organizacijske sheme in je sposobna dela z mnogimi oblikami podatkov. McAfee (2006c) je pozneje definicijo nekoliko spremenil, saj je menil, da prvotna ni bila dovolj dobro oblikovana: »poslovno okolje 2.0 predstavlja uporabo pojavljajočih socialnih računalniških okolij v podjetjih ter med podjetji in njihovimi strankami oziroma partnerji«.

Del vzroka priljubljenosti tehnologij in orodij spleta 2.0 je tudi pojav široke palete ozko usmerjenih rešitev, zato ne čudi, da so računalniška poslovna okolja 2.0 v svoji zasnovi modularna. Na ta način lahko podjetja in organizacije komponente, vire in storitve dodajajo skladno s potrebami in razvijajočimi se poslovnimi modeli. Za razliko od tradicionalnih informacijskih postavitev (glej sliko 6) je v takšnem okolju mogoče razviti, umestiti in aktivirati nove storitve brez dolgih priprav, tečajev in uskladitvenih projektov, prav tako pomembno pa je tudi to, da je zaposlenim prihranjeno mučno učenje, privajanje in prilagajanje na nove tehnološke rešitve oziroma računalniška okolja (Buytendijk et al., 2008).

 ![](primer-slika-6.png)

Slika 6: Tradicionalno poslovno okolje in poslovno okolje 2.0 (Hinchcliffe, 2006)

Do sprememb pa ni prišlo le na tehnološkem področju. Poklicni strokovnjaki in vodilni delavci imajo danes močan vpliv na delovanje organizacij, v katerih delujejo. Tradicionalne hierarhične strukture se izravnavajo in se bodo še naprej, zaposleni znotraj njih pa želijo sodelovati pri strateških odločitvah, ki vplivajo tudi na njihovo delo. Spremembe obstajajo tudi pri poslovnih procesih, saj so začele organizacije od modela, po katerem se procese določa in izvaja izključno navzven, prehajati k vrednostni verigi delovanja navznoter, kjer so stranke tiste, ki določajo delovanje in potek poslovnih procesov. V poslovnem okolju 2.0 je opravljanje posla proces nenehne interakcije in sodelovanja (Buytendijk et al., 2008).

#### 2.2.4 Semantični splet

Nova arhitektura spleta, poimenovana semantični splet, s pomočjo izgradnje novih smiselnih pomenov na spletu nudi možnost uporabe skupnega znanja. Raziskovalni semantični splet se je razvil iz tradicij umetne inteligence in ontoloških jezikov ter nudi samodejno procesiranje s pomočjo strojno razumljivih metapodatkov (Alesso in Smith, 2006).

Splošnemu prepričanju navkljub semantični splet ni nova oblika spleta, temveč le razširitev obstoječega, pri čemer se po novem informaciji dodeli dobro opredeljen pomen, kar omogoča boljše sodelovanje med človekom in računalnikom (Berners-Lee et al., 2001). Pomembno je poudariti, da se ne razlikuje od svetovnega spleta, ima pa razširitve, ki ga naredijo še bolj uporabnega (Feigenbaum et al. 2007).

Iskold (2008) je opredelil dva načina dodajanja semantične vsebine:

- (klasični) način »od spodaj navzgor«: dodajanje semantičnih metapodatkov spletnim stranem in podatkovnim bazam v internetu. Posledično vsaka spletna stran postane semantična. Težava je, da se moramo naučiti RDF/OWL (Spivack, 2008; Spivack, 2009).
- (sodobnejši) način »od zgoraj navzdol«: samodejno ustvarjanje semantičnih metapodatkov za vertikalne domene. Ustvarjajo se storitve, ki predstavljajo krovni sloj nad nesemantičnim spletom. V tem primeru se ni nikomur treba učiti RDF/OWL.

Ker obstaja kar nekaj težav klasičnega pristopa od spodaj navzgor (vsaka spletna stran mora podatke »obrazložiti« v ustrezni obliki (RDF, OWL itd.), da bi jih računalniki lahko »razumeli«), se vse bolj uveljavlja sodobnejši pristop od zgoraj navzdol, ki s pomočjo razmeroma preprostih metod (kot je recimo dodeljevanje označb iz obstoječih oblik spletnih strani) samodejno izlušči semantične informacije. Semantični splet se pogosto omenja skupaj z izrazom splet 3.0, s katerim se opisuje prihodnost spleta s tehnološkega vidika. Ker je prihodnost spleta in spletnih tehnologij še precej nejasna, je bolj primerna definicija (Spivack, 2008), ki o spletu 3.0 govori kot o tretjem desetletju interneta (obdobju 2010–2020), v katerem se pričakuje popoln razmah semantičnega spleta.

## 3. Inženirstvo v oblaku

Računalniško podprto inženirstvo ima dolgo zgodovino. Razviti so bili številni inženirski programi (CAD, programi za računske analize, inženirski informacijski sistemi, idr.), ki omogočajo hitrejši in natančnejši razvoj novih produktov. V zadnjem času pa je mogoče opaziti, še posebej v teh negotovih časih, da inženirska podjetja le še s težavo sledijo vedno hitrejšemu razvoju informacijskih tehnologij. To je še posebej očitno pri malih in srednje velikih podjetjih, ki so v gradbenem sektorju v veliki večini (Pazlar et al., 2004).

Potencialne koristi računskih virov v oblaku so očitne. Vprašanje pa je ali bi zgolj premestitev različnih programov z lokalnega računalnika v oblak izpolnilo pričakovanja inženirjev ter omogočilo dostop do najnovejših tehnologij oz. programov, ki so bila do sedaj dosegljiva le velikim podjetjem, tudi malim in srednje velikim podjetjem. Da bi izpolnili zahteve inženirjev, mora računalništvo v oblaku zagotoviti dodane vrednosti, ki bodo pomenile kvalitativen napredek v inženirskem delu. Šele takrat bomo lahko govorili o _inženirstvu v oblaku_. Inženirstvo v oblaku je torej proces, ki vključuje reševanje številnih tehnoloških in predvsem ne tehnoloških problemov.

V nadaljevanju so predstavljeni nekateri servisi v oblaku, ki predstavljajo začetne oziroma delne korake k končnemu cilju - inženirstvu v oblaku.

### 3.1 Računske analize

Računske analize so vsekakor področje, kjer so potencialne koristi računskih virov v oblaku najbolj očitne. Številni ponudniki (npr. Amazon EC3 - http://aws.amazon.com/ec2/) omogočajo dostop ali najem računskih virov na katere lahko namestimo programsko opremo, ki jo potrebujemo pri računskih analizah. Takšne računske vire lahko povežemo z različnimi splošnimi inženirskimi programi, kot sta npr. Mathematica in Matlab. Tako lahko vzpostavimo visoko-zmogljivo (angl. high-performance computing - HPC) ali visoko-propustno (angl. high-throughput computing - HTC) računsko okolje brez nakupa in predvsem kasnejšega vzdrževanja lokalnih računskih zmogljivosti. Seveda lahko podobna računska okolja vzpostavimo tudi lokalno - na UL FGG tako deluje Condor HTC računsko okolje (Dolenc et al., 2010), ki omogoča izvajanje različnih računskih analiz.

Tudi ponudniki specialnih inženirskih programov vedno pogosteje omogočajo oddaljen dostop do računskih virov na katerih se lahko izvajajo analize:

- NEEShub - http://nees.rg/: omogoča oddaljeno uporabo številnih inženirskih programov -  OpenSees, Frame3DD, SAPWood, …
- NEi Stratus - http://nenastran.com/mobile/: iPhone in iPad aplikacija (Slika 7a), ki omogoča inženirjem izračune po metodi končnih elementov.
- ICE4RISK | Approximate IDA curves - http://ice4risk.slo-projekt.info/analysis1/ (Klinc et al., 2010): spletna aplikacija (Slika 7b), ki je bila na UL FGG razvita v okviru ARRS projekta, omogoča izračun približnih IDA krivulj.

 ![](primer-slika-7.png)

Slika 7: FEA aplikacija za Apple iPhone in Apple iPad (levo) i spletna aplikacija za izračun približnih IDA krivulj (desno)

### 3.2 Informacijsko modeliranje zgradb

Informacijsko modeliranje zgradb (angl. Building Information Modelling - BIM) je metodologija dela oz. proces ustvarjanja inteligentnih modelov, ki so centralno povezani preko različnih programskih platform (Todorovič, 2011) in različni profili uporabnikov (arhitekti, gradbeniki, stojniki, investitorji, upravljalci zgradb, idr.). Centraliziranost podatkov zagotavlja pravilnost in konsistenco podatkov in s tem dvig kvalitete projektiranja ter zmanjšanje napak pri delu. Vse to pomeni na koncu nižje stroške načrtovanja, gradnje in uporabe zgradb.

Tehnologija BIM s centraliziranim podatkovnim modelom se zdi zelo primerna za imaplementacijo v oblaku, kjer so viri logično centralizirani oziroma virtualizirani - uporabnik ne ve in ga običajno tudi ne zanima kje se fizično nahajajo viri do katerih dostopa. Prav zato preseneča, da so trenutne BIM implementacije v oblaku skoraj v celoti omejene na uporabo virtualnih računalnikov (CaddForce - [http](http://www.caddforce.com/) [://](http://www.caddforce.com/) [www](http://www.caddforce.com/) [.](http://www.caddforce.com/) [caddforce](http://www.caddforce.com/) [.](http://www.caddforce.com/) [com](http://www.caddforce.com/) [/](http://www.caddforce.com/), Bim Cloud Solutions - [http](http://www.bimcloudsolutions.com/) [://](http://www.bimcloudsolutions.com/) [www](http://www.bimcloudsolutions.com/) [.](http://www.bimcloudsolutions.com/) [bimcloudsolutions](http://www.bimcloudsolutions.com/) [.](http://www.bimcloudsolutions.com/) [com](http://www.bimcloudsolutions.com/) [/](http://www.bimcloudsolutions.com/)), kjer so nameščeni različni programi, ki omogočajo informacijsko modeliranje zgradb (Revit, Revit MEP, Ecotect, Archicad, Allplan, itd ). Morda je tako Graphisoft BIM Server (http://www.graphisoft.com/products/archicad/teamwork.html) implementacija še najbliže pravemu SaaS modelu računalništva v oblaku. Le ta omogoča različnim instancam programa Archicad in drugim programom za informacijsko modeliranje zgradb hkraten dostop do skupnega oddaljenega BIM modela.

Na področju klasičnih CAD orodij ter orodij za vizualizacijo BIM modelov pa je mogoče zaslediti velik premik v smeri računalništva v oblaku. Tako je npr. Graphisoft izdalal program BIMx (Slika 8a, [http](http://www.graphisoft.com/products/bim-explorer/) [://](http://www.graphisoft.com/products/bim-explorer/) [www](http://www.graphisoft.com/products/bim-explorer/) [.](http://www.graphisoft.com/products/bim-explorer/) [graphisoft](http://www.graphisoft.com/products/bim-explorer/) [.](http://www.graphisoft.com/products/bim-explorer/) [com](http://www.graphisoft.com/products/bim-explorer/) [/](http://www.graphisoft.com/products/bim-explorer/) [products](http://www.graphisoft.com/products/bim-explorer/) [/](http://www.graphisoft.com/products/bim-explorer/) [bim](http://www.graphisoft.com/products/bim-explorer/) [-](http://www.graphisoft.com/products/bim-explorer/) [explorer](http://www.graphisoft.com/products/bim-explorer/) [/](http://www.graphisoft.com/products/bim-explorer/)), ki omogoča vizualizacijo in deljenje BIM modelov na napravah z operacijskim sistemom iOS. Autodesk pa je že pred časom predstavil produkt AutoCAD WS (https://www.autocadws.com/), ki omogoča urejanje DWG datotek na spletu oz. namenskih programov, ki tečejo na različnih napravah (Slika 8b).

 ![](primer-slika-8.png)

Slika 8: Program BIMx omogoča vizualizacijo BIM modela na prenosnih napravah (levo) in AutoCAD WS omogoča urejanje DWG datotek tudi na tabličnih računalnikih in pametnih telefonih (desno).

### 3.3 Komunikacija in sodelovanje

Ob prehodu iz tradicionalnega v z IKT podprto komunikacijo in sodelovanje v gradbeništvu se je spremenil predvsem način interakcije med udeleženci. Tako se je topologija iz polno povezane, kjer je lahko vsak udeleženec komuniciral z vsakim neposredno, s pomočjo informacijsko-komunikacijskih orodij spremenila v zvezdasto, kjer udeleženci skoraj vedno komunicirajo prek posrednika (naj bo to projektni portal, produktni model, forum ali strežnik FTP ipd.).

Skladno s prehodom se je razvil pristop h komunikaciji in sodelovanju, ki mu pravimo &quot;od zgoraj navzdol&quot;. Orodja za sodelovanje so vnaprej določena (predpisana), pristop do IKT in orodij je centraliziran, komunikacijske poti pa so ustaljene in strogo sledijo organizacijski hierarhiji. Običajno si IKT rešitve nameščene na centralnih strežnikih, ki so v lasti organizacije, ki jih tudi vzdržuje. Tak pristop se je v preteklosti uveljavil predvsem zato, ker omogoča strožji nadzor in boljšo varnost podatkov in informacij, ki se shranjujejo znotraj same organizacije. Danes ugotavljamo, da ni najbolj primeren, saj centralizirano izbrana in vodena IKT orodja ne sledijo vedno poslovnim procesom in navadam končnih uporabnikov, imajo strmejšo krivuljo učenja ter ne sledijo najnovejšim dosežkom s področij sodelovanja, komunikacije, spletnih tehnologij in uporabniških vmesnikov.

Tudi zato se v zadnjem času v tujini pojavljajo namenske IKT rešitve za sodelovanje, prilagojene delu, nalogam in procesom v gradbeništvu, ki tečejo v računalniškem oblaku in ki sledijo najnovejšim trendom. Takšne rešitve so denimo:

- Build It Live (http://www.builditlive.com/): SaaS programska rešitev za vodenje gradbeniških projektov ki nudi učinkovita orodja za komunikacijo v projektu od faze projektiranja do faze zaključka del, tako na nivoju dokumentacije kot tudi na relaciji človek-človek.
- Fusion Live (http://www.sword-ctspace.com/section/view/495/fusionlive): oblačna storitev za upravljanje z dokumenti, procesi, projekti in sodelovanje.
- Aconex (http://www.aconex.com/): SaaS rešitev za upravljanje z načrti, BIM in 3D modeli, pogodbami, poročili, terminskimi plani in ostalo dokumentacijo.
- Procore (http://www.procore.com/): orodja za upravljanje z informacijami, pogodbami, terminskimi plani ipd. Dobro se povezuje s klasičnimi programskimi orodji kot so denimo Microsoft Project, Primavera Suretrak itd.
- Jonas (http://www.jonas-construction.com/products): popolna SaaS storitev za majhno in srednja podjetja, ki se ukvarjajo z upravljanjem in vzdrževanjem stanovanjskih in poslovnih stavb.

Čedalje več komunikacije in sodelovanja v gradbeništvu pa danes poteka s pomočjo sodobnih spletnih storitev, ki niso nujno vpeljane s strani vodstvenih kadrov, ampak si jih izberejo končni uporabniki sami, saj so jih navajeni uporabljati v svojem vsakdanjem življenju. Trend se imenuje tehnološki populizem in ga Gartner (2008) definira kot »smer sprejemanja, ki jo vodi s tehnologijo dobro seznanjena delovna sila, ki sama skrbi za orodja za sodelovanje, informacijske vire in socialna omrežja, za kar je potrebna minimalna (ali pa tudi to ne) tekoča informacijska podpora jedra organizacije«. Gre za pristop &quot;od spodaj navzgor&quot;, primeri takšnih storitev pa so denimo:

- Google Dokumenti (http://docs.google.com/): pisarniška orodja, ki jih lahko uporabljamo kot storitve preko brskalnika in so na voljo brezplačno - nadomešča priljubljeni pisarniški paket Microsoft Office (opomba: članek, ki ga berete, so soavtorji napisali z orodjem Google Dokumenti);
- Skype (http://www.skype.com/): programsko orodje, ki omogoča VoIP telefonijo, takojšnje sporočanje, deljenje namizja, konferenčne klice ipd.;
- Vox.io (http://vox.io/): SaaS rešitev, ki ponuja VoIP telefonijo preko brskalnika;
- Dropbox (http://www.dropbox.com/): SaaS rešitev za deljenje datotek med uporabniki;
- Flowr (http://theflowr.com/): storitev za sodelovanje, izmenjavo idej, določanje nalog in komunikacijo med sodelavci.

Projekcije kažejo, da bi naj kmalu bile zahteve in pričakovanja uporabnikov neposredni povod za nakup oziroma najem kar polovice vseh programskih orodij, strojne opreme in ostalih storitev za delo (Gartner, 2008).

## 4. Zaključki

Gradbena informatika stopa v zrelo fazo, kar pomeni, da postaja tako vseprisotna, zmogljiva in prijazna, da izginja kot razvojni problem v podjetjih. Razkorak med tem, kaj je na voljo na trgu, kaj je mogoče, in kaj praksa uporablja, se veča. Storitve v oblaku, virtualizacija in outsourcing infrastrukturnih oz. komunalnih storitev informatike bo verjetno povzročila organizacijske spremembe, zmanjšanje in izginjanje &quot;računskih centrov&quot; in &quot;oddelkov za informatiko&quot;.

Raziskovalno ostajajo zanimiva tehnološka vprašanja povezana z masivno virtualizacijo in storitvami v oblaku, kar bomo raziskovali v EU projektu ISES (Intelligent Services for Energy-Efficient Design and Life Cycle Simulation, FP7-ICT-2011-7) ki bo stekel jeseni 2011. Celovitost informacij, virtualizacija informacijske infrastrukture in organizacij odpira cel kup vprašanj pravne narave, od avtorskih pravic za rezultate sodelovanja do pristojnosti krajevne zakonodaje za oblak, ki nima lokacije. Vsaj tako pa so zanimiva vprašanja prenosa znanja in študij sprememb, ki jih v organizacije prinaša nova tehnologija, vpliv tehnologije v ožjem smislu, na procese v gradbeništvu, in v širšem smislu, na družbo kot celoto. Slednje je predmet proučevanja projekta EINS (European InterNet Science, FP7-ICT-2011-7), ki bo tudi stekel jeseni 2011.

## 5. Literatura

Alesso, H.P. in Smith, C.F. 2006. Thinking on the Web: Berners-Lee, Gödel and Turing. Hoboken, New Jersey, ZDA, Wiley-Interscience: 290 str.

Becerik, B. 2004. A review on past, present and future of web based project management &amp; collaboration tools and their adoption by the US AEC industry. International Journal of IT in Architecture, Engineering and Construction 2, 3: 233–248.

Berners-Lee, T., Hendler, J., and Lassila, O. 2001. The semantic web: A new form of web content that is meaningful to computers will unleash a revolution of new possibilities. Scientific American 284, 5: 34–43.

Buytendijk, F., Cripe, B., Henson, R. in Pulverman, K. 2008. Business Management in the Age of Enterprise 2.0: Why Business Model 1.0 Will Obsolete You. Oracle Corporation, http://www.oracle.com/solutions/business\_intelligence/docs/epm-enterprise20-whitepaper.pdf

Cerovšek, T. 2002. Distribuirana računalniško integrirana gradnja pri pogojih necelovitosti. Doktorska disertacija. Ljubljana, Univerza v Ljubljani, Fakulteta za gradbeništvo in geodezijo: 308 str.

CCUCDG, 2009a. Cloud computing use cases. A white paper, Draft 3, 20. 7. 2009,

http://cloud-computing-use-cases.googlegroups.com/web/Whitepaper\_Draft\_3.pdf

CCUCDG, 2009b. Cloud computing use cases. A white paper, Version 2.0,

http://cloud-computing-use-cases.googlegroups.com/web/Cloud\_Computing\_Use\_Cases\_Whitepaper-2\_0.pdf

Dainty, A., Moore, D. in Murray, M. 2006. Communication in Construction: Theory and practice. London, VB, Taylor &amp; Francis: 263 str.

Dolenc, M., Klinc, R., Peruš, I., Dolšek, M. (2010). The ICE4RISK computing environment. V: TOPPING, Barry H. V. (ur.). Proceedings of the Seventh International Conference on Engineering Computational Technology, Valencia - Spain, 14-17 September 2010, (Civil-Comp Proceedings, 94). Stirling: Civil-Comp Press, cop. 2010, str. 1-8, ilustr.

Easynet, 2008. Outlook cloudy as SMBs not ready for hosted apps, A study of UK Small and Medium sized Business&#39; readiness for cloud computing and Software as a Service (SaaS), Easynet connect.

Feigenbaum, L., Herman, I., Hongsermeier, T., Neumann, E., in Stephen, S. 2007. The Semantic Web in Action. Scientific American 297, 6: 90–96.

Fuller, D., Achtermann, D., McLeod, C. 2009. High-Tech Tools for the Library Media Center: The Future from a Low-tech Point of View. ZDA, Springer US, Educational Media and Technology Yearbook 34: 189–197

Hartman, T. in Beck, L. 2009. Defining the business value of cloud computing. Avanade Point of View, http://www.avanade.be/\_uploaded/pdf/thoughtleadership/cloudpovfinalrevised090909874764.pdf

Gartner 2008. Gartner Highlights Key Predictions for IT Organisations and Users in 2008 and Beyond. Gartner Newsroom, http://www.gartner.com/it/page.jsp?id=593207

Hinchcliffe, D. 2006. Enable richer business outcomes: Free your intranet with Web 2.0. ZDnet.com, http://blogs.zdnet.com/Hinchcliffe/?p=57

Iskold, A. 2008. Semantic Web Patterns: A Guide to Semantic Technologies. ReadWriteWeb,

http://www.readwriteweb.com/archives/semantic\_web\_patterns.php

Jewell, H. 2007. The Future of the Web – 7 Reasons to Become Web 2.0 Compatible. EzineArticles,

http://ezinearticles.com/?The-Future-of-the-Web---7-Reasons-to-Become-Web-2.0-Compatible&amp;id=778096

McAfee, A. 2006a. Enterprise 2.0: The Dawn of Emergent Collaboration. MIT Sloan Management Review 47, 3: 21–28.

McAfee, A. 2006b. Enterprise 2.0 vs. SOA. The Business Impact of IT. Andrew McAfee&#39;s Blog, http://andrewmcafee.org/2006/05/enterprise\_20\_vs\_soa/

McAfee, A. 2006c. Enterprise 2.0, version 2.0. The Business Impact of IT. Andrew McAfee&#39;s Blog, http://andrewmcafee.org/2006/05/enterprise\_20\_version\_20/

Kempiners, J. in Beck, L. 2007. Service–Oriented Architecture. Avanade Point of View, http://www.avanade.com/\_n/\_uploaded/pdf/thoughtleadership/soapovsept07460866.pdf

Klinc, R, Peruš, I., Dolšek, M., Dolenc, M. (2010). Web based computing environment for prediction of approximate seismic response parameters of structures. V: MENZEL, Karsten (ur.), SCHERER, Raimar J. (ur.). eWork and eBusiness in architecture, engineering and construction : proceedings of the European Conference on Product and Process Modelling 2010, Cork, Republic of Ireland, 14-16 September 2010. Boca Raton, Fla.: CRC; London: Taylor &amp; Francis [distributor], cop. 2010, str. 39-44, ilustr.

Komisija Evropskih skupnosti, 2009a. Software 2.0: Rebooting Europe&#39;s software industry, report of an industry expert group on a European software strategy. Version 3.0.

Komisija Evropskih skupnosti, 2009b. Opinion 5/2009 on online social networking. Article 29 data protection working party. Prevzeto dne 12. 6. 2009.

Medeot, T. 2007. Uporaba sodobnih pristopov pri upravljanju poslovnih procesov. Diplomsko delo. Ljubljana, Univerza v Ljubljani, Ekonomska fakulteta: 43 str.

Mell, P. in Grance, T. 2009. The NIST Definition of Cloud Computing (Version 15). National Institute of Standards and Technology, Information Technology Laboratory, http://csrc.nist.gov/groups/SNS/cloud-computing/cloud-def-v15.doc

Miller, P. 2005. Web 2.0: Building the New Library. Ariadne 45, http://www.ariadne.ac.uk/issue45/miller/

Nivi, B. 2005. What is Web 1.0? Osebni blog Babaka Nivija, http://www.nivi.com/blog/article/what-is-web-10

O&#39;Reilly, T. 2005. What is Web 2.0 – Design Patterns and Business Models for the Next Generation of Software. O&#39;Reilly Media, http://oreilly.com/web2/archive/what-is-web-20.html

O&#39;Reilly, T. 2006. Web 2.0 Compact Definition: Trying Again. O&#39;Reilly Radar, objavljeno: 10. 12. 2006, http://radar.oreilly.com/archives/2006/12/web-20-compact-definition-tryi.html

Pazlar, T., Dolenc, M. in Duhovnik, J. 2004. Rezultati raziskave prodAEC o rabi informacijskih tehnologij v arhitekturi, inženirstvu in gradbeništvu v Sloveniji. Gradb. vestn. 53, 9: 223–229.

Shuen, A. 2008. Web 2.0: A Strategy Guide. Sebastopol, Kanada, O&#39;Reilly Media: 272 str.

Spivack, N. 2007a. How the WebOS evolves? Nova Spivack blog, objavljeno: 9. 2. 2007, http://www.novaspivack.com/technology/how-the-webos-evolves

Spivack, N. 2008. Making sense of the semantic web. Predstavitev na konferenci &quot;The next web conference 2008&quot;, Amsterdam, 3. 4. 2008.

Spivack, N. 2009. The Evolution of the Web: Past, Present, Future. Nova Spivack blog, objavljeno: 21. 12. 2009, http://www.novaspivack.com/uncategorized/the-evolution-of-the-web-past-present-future

Todorovič, M. 2011. Pot implementacije BIM-a. Klik, št. 131, september 2011.

Turk, Ž. 1999. Four questions about construction information technology. V: Berkeley-Stanford CE&amp;M Workshop, Defining a Research Agenda for AEC Process/Product Development in 2000 and Beyond, http://www.ce.berkeley.edu/~tommelein/CEMworkshop.htm

Turk, Ž. 2001b. Internet Information and Communication Systems for Civil Engineering – A Review. V: Topping, B.H.V. (ur.). Civil and Structural Engineering Computing, Saxe-Coburg Publications: 1–26.

Turk, Ž. in Cerovšek, T. 2001. A Prototype Portal to Web Based Collaborative Engineering. V: Amarjit Singh (ur.). Creative Systems in Structural and Construction Engineering, Brookfield, Rotterdam, A.A. Balkema: 247–352.

Williams, P. in Cox,S. 2009. Engineering in the Cloud: An Engineering Software + Services Architecture Forged in Turbulent Times. The Architecture Journal, objavljeno: Junij 2009, http://msdn.microsoft.com/en-us/architecture/aa894305
