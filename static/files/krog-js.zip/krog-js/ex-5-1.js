function izracun() {
  var r = document.getElementById('radij').value;
  var pl = Math.PI * r * r;
  var str = "Ploščina kroga je " + pl; 
  document.getElementById("results").innerHTML = str;
}
